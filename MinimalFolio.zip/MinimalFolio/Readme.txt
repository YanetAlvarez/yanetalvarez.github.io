Thanks for downloading this template!

Template Name: MinimalFolio
Template URL: https://bootstrapmade.com/minimalfolio-bootstrap-portfolio-template/
Author: BootstrapMade.com
License: https://bootstrapmade.com/license/
